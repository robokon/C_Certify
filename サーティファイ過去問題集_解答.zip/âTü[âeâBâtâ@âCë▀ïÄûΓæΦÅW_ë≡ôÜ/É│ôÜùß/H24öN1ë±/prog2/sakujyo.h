/************************************/
/*  sakujyo.h                       */
/*    �o�^�폜�����w�b�_�t�@�C��    */
/************************************/

int  touroku_sakujyo( void );

#ifdef TOI2
void init_sakujyo_flg( void );
int  sakujyo_commit( void );
#endif

static int  codedata_tbl_delete( int kaiin_code );
static int  kojin_data_delete( int kaiin_code );
static int  akicode_tbl_add( int kaiin_code );

