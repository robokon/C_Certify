/************************************/
/*  nyuukai.h                       */
/*    ����o�^�����w�b�_�t�@�C��    */
/************************************/

int  nyuukai_touroku( void );
#ifdef TOI2
int data_import( void );
static int import_file(FILE *fp, struct KEISOKU_TBL *p);
#endif

static int  akicode_tbl_update( void );
static int  keisoku_tbl_add( long *fptr, int kaiin_code );
static int  codedata_tbl_update( int kaiin_code, long fptr );

