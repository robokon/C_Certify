/************************************************/
/*  main.h                                      */
/*    �A�X���`�b�N�N���u����Ǘ��w�b�_�t�@�C��  */
/************************************************/

static int  codedata_tbl_create( void );
static int  akicode_tbl_create( void );

int  akicode_tbl_read( void );
int  kakunin_input( char *msg );
int  kojin_data_read( int kaiin_code );
void kojin_data_disp( int kaiin_code, char *msg );
struct KEISOKU_TBL init_kojin_keisoku_tbl( void );

#ifdef TOI2
static int huka_keisuu_read( void );
static void huka_keisuu_disp( void );
#endif
