/************************************/
/*  sakujyo.h                       */
/*    �o�^�폜�����w�b�_�t�@�C��    */
/************************************/

int  touroku_sakujyo( void );

static int  codedata_tbl_delete( int kaiin_code );
static int  kojin_data_delete( int kaiin_code );
static int  akicode_tbl_add( int kaiin_code );

